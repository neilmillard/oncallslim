test output <?php echo $foo; ?> <?php echo $abc; ?>
