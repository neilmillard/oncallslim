

To start testing add PHP Coverage lib:


testing/cli/phpcoverage.inc.php
testing/phpcoverage/


Download from:
http://sourceforge.net/projects/phpcoverage/