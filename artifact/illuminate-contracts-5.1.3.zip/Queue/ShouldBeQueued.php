<?php

namespace Illuminate\Contracts\Queue;

/**
 * @deprecated since version 5.1. Use the ShouldQueue interface.
 */
interface ShouldBeQueued extends ShouldQueue
{
}
