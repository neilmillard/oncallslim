<?php

namespace Illuminate\Contracts\Validation;

use RuntimeException;

class UnauthorizedException extends RuntimeException
{
}
